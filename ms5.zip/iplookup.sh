#!/bin/bash
########################################################################
#	iplookup.sh
#	  Author:	      Connor Cole  
#	  Date:		      2021-08-06
# 	Last revised:	2025-02-07
#	  Description:	Improved IP lookup script
#		- Removes repetitive lookups to ipinfo.io
#		- Uses regex and awk to filter out hits <100, instead of doing 
#     a sequential check (if/else)
#		- Keeps found IP information in memory, instead of writing 
#     temp files
#		- Outputs info on demand, instead of making the user sit through
#     it all
#		- Improved regex for matching valid IP addresses
#   - NEW: option to add CIDR blocks instead of IPs
#   - NEW: option to reset the firewall
#
#	  NOTE: Only works with /var/log/auth.log
########################################################################

#colors
RESET="\e[0m"   #for color text output
CYAN="\e[36m"
MAGENTA="\e[31m"
YELLOW="\e[38;5;228m"
PURPLE="\e[38;5;141m"
RED="\e[38;5;196m"
GREEN="\e[38;5;43m"
BLUE="\e[38;5;26m"
LTPURP="\e[38;5;219m"
ORANGE="\e[38;5;216m"
#formatting
HLINE="============================="

############### ERROR CHECKING ######################
#have to sudo to access log files

if [[ $(id -u) != '0' ]]
then
  printf $RED"Error: Elevated priveliges required...\n"$RESET
  exit 1
fi

#check for proper usage (correct # of arguments - 0)
#needs 1 argument for filename 
if [[ $# -ne 1 ]]
then
  printf $RED"Error: Usage ./iplookup.sh <file_name>\n"$RESET
  exit 2
fi

#check that input file exists
if [[ ! -f "$1" ]]
then
  printf $RED"Error: $1 not found...\n"$RESET
  exit 3
fi

############# DONE ERROR CHECKING ##################


#IP patterns
QUAD="((25[0-5])|(2[0-4][0-9])|(1[0-9][0-9])|([1-9]?[0-9]))" #took a while because i missed outer parentheses
IP="\b${QUAD}\.${QUAD}\.${QUAD}\.${QUAD}\b"

#misc variables
i=0   #counter for attempts
uniqIps=0 #counter for unique IP addresses
token=b580b2fc1d2b3a

printf "Working... "

#scrape IPs from input file, sort, get unique
#(with counts), trim off anything with <100
#hits, sort by # of hits. in /var/log/auth.log, 
#the IP address is recorded three times for each offense.
#filtering on "rhost=$IP" trims off the other two entries
# ** develop pipeline from the command prompt! **

regs=$(grep "rhost=" $1 | grep -Eo $IP | 
sort | uniq -c | awk '$1>=100' | sort -nr)

# this is also a good place to calculate the counts of 
# unique IP addresses and total count

#take $regs output, filter on IP, and count how many unique ones we have
uniqIps=$(echo $regs | grep -Eo $IP | awk '{i+=1} END {print i}')
#similar, but replace each $IP with a newline to count how many attempts we have 
i=$(echo $regs | sed -E "s/$IP/\n/g" | awk '{i+=$1} END {print i}')


echo "Done!"
sleep 1s  
echo

############  FUNCTIONS  ############
#display menu
function show_menu () {
	# Show Menu function
  clear
  printf $GREEN"%s\n" "$HLINE"
  printf "========== Select ===========\n"
  printf "%s\n" "$HLINE"
  printf "1. Get unique IP addresses\n"
  printf "2. Show detailed information\n"
  printf "3. Add new offenders to UFW\n"
  printf "4. Bracket IP subnet / add to UFW\n"
  printf "5. Show firewall rules ('q' to quit)\n"
  printf "6. Reset the firewall\n"
  printf "7. Quit\n"
  printf "%s\n"$ORANGE "$HLINE"

}

#pause output
function pause () {
  printf $PURPLE
  read -n1 -p "Press any key to continue..." </dev/tty
  printf $RESET
  return 0
}

#before adding a CIDR block, it'd be nice
#to make sure that an IP address within 
#that block isn't already in UFW and 
#delete it, if so
function delete_ip () {
  target_IP="$1"

  #find the UFW rule # associated with the IP
  #address
  rule_no=$(sudo ufw status numbered | grep -w $target_IP | sed -n 's/^\[\([0-9]\+\)\].*/\1/p')

  #if there is a rule associated with the provided
  #IP address, delete it 
  if [[ $rule_no ]]
  then
    sudo ufw --force delete "$rule_no" &> /dev/null 2>&1
    return 0   #return success
  fi

  return 1  #return fail
}

#display the unique IP addresses on demand
function display_unique_ips () {
  clear
  printf $MAGENTA
  echo "$regs" | awk '{print $2" ("$1" attempts)"}'
  printf $RESET
  return 0
}

#print detailed info on the offenders
function print_info () {
  clear
  
  while IFS= read -r line;
  do
    currIP=$(echo $line | awk '{print $2}')
    count=$(echo $line | awk '{print $1}')
    clear

    printf $RED
    printf "IP Information\n"
    printf $currIP
    printf $RESET
    curl ipinfo.io/$currIP?token=$token
    printf $RED"($count attempts)\n\n"$RESET
    read -n1 -p "Press any key to to continue ('q' to quit)" quit </dev/tty
    case $quit in 
      [Qq]) break;;
    esac
  done <<< "$regs"
  return 0
}

#add the IPs to the firewall. if 'y', have to check
#and make sure that the IP isn't already in the firewall
function add_ips_to_ufw () {
  clear
  echo "Add singleton IP addresses to UFW"
  while IFS= read -r line;
  do
    currIP=$(echo $line | awk '{print $2}')
    currTrio=$(echo "${currIP}" | awk -F. '{print $1"."$2"."$3}')
    currCIDR="${currTrio}.0/24"
    # checks for CIDR block first, only adding if it's not in a CIDR and not already in UFW
    if (ufw status | grep -qw "$currCIDR");
    then
      printf $RED
      printf "$currIP      .....in an existing CIDR block!\n"
      printf $RESET
    elif  !(ufw status | grep -qw "$currIP"); 
    then 
      ufw insert 1 deny from $currIP &> /dev/null
      printf $GREEN
      printf "$currIP      .....Added!\n"
    
    else
      printf $RED
      printf "$currIP      .....already in UFW!\n"
      printf $RESET
    fi
  done <<< "$regs"
  return 0
  pause
}

#modify the offenders to the CIDR notation for each
#e.g., 192.168.1.0/24. Strips the last octet of
#each offender's IP address and adds "0/24". this
#will block up to 256 addresses within the range 
#(often attacks come in from multiple hosts
#within a given range)
function bracket_ips () {
  clear
  echo "Modify IPs to CIDR (x.x.x.0/24)"
  echo "Delete IP from UFW"
  echo "Insert CIDR to UFW"


  while IFS= read -r line;
  do
    currIP=$(echo $line | awk '{print $2}')
    currTrio=$(echo "${currIP}" | awk -F. '{print $1"."$2"."$3}')
    currCIDR="${currTrio}.0/24"
    
    printf $GREEN"Checking...."$RESET

    if (ufw status | grep -qw "$currIP"); then
      delete_ip $currIP &> /dev/null 
    fi

    if !(ufw status | grep -qw "$currCIDR");
    then
      ufw insert 1 deny from $currCIDR &> /dev/null
      printf $GREEN"            ....Added!\n"$RESET
    else
      printf $RED"              ....Already in UFW!\n"$RESET
    fi
  done <<< "$regs"
  
  return 0
}

#show all firewall rules (run thru less)
function show_firewall () {
  clear
  printf $RESET
  ufw status numbered | less
  return 0
}

#if the firewall becomes too conjested,
#reset it to allow only ssh, http, and 
#https. Then, current offenders can be added
function reset_firewall () {
  clear
  while true
  do
    printf $RED
    printf "\n"
    read -n1 -p "Are you sure you want to reset the firewall? (y/n)  " reset
    printf "\n"
    printf $RESET
    case $reset in 

      y) 
        ufw --force disable &> /dev/null
        ufw --force reset &> /dev/null

        echo " ** UFW reset **" 

        ufw allow ssh &> /dev/null
        ufw allow http &> /dev/null
        ufw allow https &> /dev/null

        ufw enable &> /dev/null
        echo " ** UFW enabled **" 

        find /etc/ufw -name '*.rules.*' -delete &> /dev/null
        break;;
      n)
        break;;
      *)
        printf $RED"\nPlease enter y or n....\n"$RESET
        pause
        
    esac 
  done

  return 0
}

#################################
############  START  ############
#################################

#display totals
printf $CYAN"There were $i total attempts..\n"
# Display count totals
printf $CYAN"From $uniqIps unique IP addresses \n\n\n"$RESET
pause

# main loop
while true
do
  clear
  show_menu
  read -n1 -p "** ENTER SELECTION: " select

    case $select in 
      1) display_unique_ips
        pause;;

      2) print_info;;

      3) add_ips_to_ufw
        pause;;

      4) bracket_ips
        pause;;
      
      5) show_firewall;;

      6) reset_firewall
        pause;;
      7) break;;

      *)printf $RED"\n\nPlease enter a valid value (1-7)\n"$DEFAULT
        pause;;
    esac
done 

printf $RESET
echo
echo "Done! Bye now"
echo

exit 0
